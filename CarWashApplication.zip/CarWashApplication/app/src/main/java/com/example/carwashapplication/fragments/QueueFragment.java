package com.example.carwashapplication.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.carwashapplication.R;
import com.example.carwashapplication.adapters.QueueListAdapter;
import com.example.carwashapplication.domain.Car;
import com.example.carwashapplication.domain.CarQueue;
import com.example.carwashapplication.domain.Queue;
import com.example.carwashapplication.util.BaseFragment;

import java.text.SimpleDateFormat;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class QueueFragment extends BaseFragment {
    private RecyclerView _recyclerView;
    private QueueListAdapter adapter;
    private Car[] queueCarArray;
    private RelativeLayout _washingLayout;
    private TextView _checkInDate;
    private TextView _plateNumber;

    public static QueueFragment newInstance() {
        return new QueueFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getActivity().setTitle("Queue");
        setHasOptionsMenu(false);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_queue, container, false);

        initialization(view);
        loadData();
        return view;
    }

    private void initialization(View view){
        _recyclerView = view.findViewById(R.id.recyclerView);
        _recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        _recyclerView.setItemAnimator(new DefaultItemAnimator());

        _washingLayout = view.findViewById(R.id.washingLayout);
        _plateNumber = view.findViewById(R.id.plateNumber);
        _checkInDate = view.findViewById(R.id.checkInDate);
    }

    public void update()
    {
        if(adapter!=null) {
            adapter.notifyAll();
        }
    }

    private void loadData()
    {
        Queue<Car> queueCar = CarQueue.getInstance();
        queueCarArray = new Car[queueCar.getSize()];
        Car washingCar = queueCar.peek();
        if(washingCar!=null)
        {
            if(washingCar.isWashing())
            {
                _washingLayout.setVisibility(View.VISIBLE);
                _plateNumber.setText(washingCar.getPlateNumber());
                SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                _checkInDate.setText(String.format("Check In: %1$s",format.format(washingCar.getCheckInDateTime())));
            }
            else {
                _washingLayout.setVisibility(View.INVISIBLE);
            }
        }

        for(int i=0;i<queueCar.getSize();i++)
        {
            queueCarArray[i] = queueCar.getQueue()[i];
        }

        adapter = new QueueListAdapter( getContext(),queueCarArray);
        _recyclerView.setAdapter(adapter);
    }
}
